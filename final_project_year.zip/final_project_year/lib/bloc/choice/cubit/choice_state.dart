part of 'choice_cubit.dart';

class ChoiceState {
  int gavernorate;
  int city;
  int village;
  ChoiceState({
    required this.gavernorate,
    required this.city,
    required this.village,
  });
}