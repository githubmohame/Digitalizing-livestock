import 'package:final_project_year/bloc/choice/cubit/choice_cubit.dart';
import 'package:final_project_year/common_component/main_diwer.dart';
import 'package:final_project_year/main_screens/farm_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ConnectFarmAndFarmerScreen extends StatelessWidget {
  ConnectFarmAndFarmerScreen({Key? key}) : super(key: key);
  List<TextEditingController> list = [
    TextEditingController(),
    TextEditingController(),
    TextEditingController(),
    TextEditingController()
  ];
  bool isCheck = false;
  @override
  Widget build(BuildContext context) {
    final _formKey = GlobalKey<FormState>();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        drawer: MainDrawer(index: 3),
        appBar: AppBar(
            backgroundColor: const Color(0x0FF9c6644),
            title: const Text("ربط المزرعة بالمربين")),
        body: SingleChildScrollView(
          child: Form(
              child: Column(
            children: [
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  controller: list[0],
                  validator: (value) {
                    return null;
                  },
                  decoration: const InputDecoration(
                      border: InputBorder.none, hintText: "كود المزرعة"),
                  keyboardType: TextInputType.text,
                ),
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  controller: list[0],
                  validator: (value) {
                    return null;
                  },
                  decoration: const InputDecoration(
                      border: InputBorder.none, hintText:'اسم المزرعة'),
                  keyboardType: TextInputType.text,
                ),
              ),

            Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  controller: list[3],
                  validator: (value) {
                    return null;
                  },
                  decoration: const InputDecoration(
                      border: InputBorder.none, hintText: "التكلفة الكلية"),
                  keyboardType: TextInputType.number,
                ),
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  controller: list[0],
                  validator: (value) {
                    return null;
                  },
                  decoration: const InputDecoration(
                      border: InputBorder.none, hintText:"الرقم القومي للمربي"),
                  keyboardType: TextInputType.text,
                ),
              ),

              Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  OutlinedButton(
                    style: ButtonStyle(
                        fixedSize: MaterialStateProperty.all(const Size(200, 50)),
                        shape: MaterialStateProperty.resolveWith((states) =>
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30))),
                        backgroundColor: MaterialStateProperty.resolveWith(
                            (states) => Colors.grey),
                        overlayColor: MaterialStateProperty.resolveWith(
                            (states) => Colors.red)),
                    onPressed: () {},
                    child: const Text(
                      "مسح",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  OutlinedButton(
                    style: ButtonStyle(
                        fixedSize: MaterialStateProperty.all(const Size(200, 50)),
                        shape: MaterialStateProperty.resolveWith((states) =>
                            RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30))),
                        backgroundColor: MaterialStateProperty.resolveWith(
                            (states) => Colors.grey),
                        overlayColor: MaterialStateProperty.resolveWith(
                            (states) => Colors.brown)),
                    onPressed: () {
                      
                    },
                    child: const Text(
                      "حفظ",
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                 
                ],
              ),
            ],
          )),
        ),
      ),
    );
  }
}
