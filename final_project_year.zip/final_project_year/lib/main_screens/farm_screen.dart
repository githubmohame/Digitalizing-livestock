import 'dart:async';

import 'package:final_project_year/bloc/choice/cubit/choice_cubit.dart';
import 'package:final_project_year/common_component/main_diwer.dart';
import 'package:final_project_year/main_screens/Show_info.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:final_project_year/bloc/select_muilt_type/cubit/select_muilt_type_cubit.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class CustomeDropdownButton extends StatefulWidget {
  int value;
  String text;
  bool expanded = false;
  List<Map<String, dynamic>> list;
  Function(int value)? func;
  CustomeDropdownButton({
    Key? key,
    this.func,
    required this.value,
    required this.text,
    required this.expanded,
    required this.list,
  }) : super(key: key);

  @override
  State<CustomeDropdownButton> createState() => _CustomeDropdownButtonState();
}

class _CustomeDropdownButtonState extends State<CustomeDropdownButton> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: FutureBuilder<List<Map<String, dynamic>>>(
        builder: (context, snapshot) => Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(widget.text),
              ],
            ),
            DropdownButton<int>(
              isExpanded: widget.expanded,
              underline: Container(),
              focusColor: Colors.transparent,
              alignment: Alignment.bottomLeft,
              value: widget.value,
              items: List.generate(widget.list.length, (index) {
                return DropdownMenuItem(
                    value: widget.list[index]["id"],
                    child: Text(widget.list[index]["name"]));
              }),
              onChanged: (value) {
                setState(() {
                  widget.value = value ?? 0;
                  if (widget.func is Function(int value) && value is int) {
                    widget.func!(value);
                  }
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}

Future<List<Map<String, dynamic>>> f1() {
  return Future<List>.delayed(const Duration(seconds: 10)).then((value) => [
        {"kill": 'see'}
      ]);
}

class FarmScreen extends StatelessWidget {
  const FarmScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        drawer: MainDrawer(index: 0),
        appBar: AppBar(
            backgroundColor: const Color(0x0FF9c6644),
            title: const Text("اضافه المزرعة")),
        body: SingleChildScrollView(
          child: Form(
              child: Column(
            children: [
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  validator: (value) {},
                  decoration: const InputDecoration(
                      border: InputBorder.none, hintText: 'رقم السجل الضريبي'),
                  keyboardType: TextInputType.number,
                ),
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  validator: (value) {},
                  decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: 'المساحة الكلية للمزرعة'),
                  keyboardType: TextInputType.number,
                ),
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  validator: (value) {},
                  decoration: const InputDecoration(
                      border: InputBorder.none, hintText: 'ادخل اسم المزرعة'),
                  keyboardType: TextInputType.text,
                ),
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  validator: (value) {
                    try {
                      return int.parse(value ?? "0") <= 0
                          ? " العدد يجب ان يكون اكبر من 0"
                          : null;
                    } catch (e) {
                      return null;
                    }
                  },
                  decoration: const InputDecoration(
                      border: InputBorder.none, hintText: "اعدد الملاعب"),
                  keyboardType: TextInputType.number,
                ),
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  validator: (value) {
                    try {
                      return int.parse(value ?? "0") <= 0
                          ? "  0العدد يجب ان يكون اكبر من او يساوي"
                          : null;
                    } catch (e) {
                      return null;
                    }
                  },
                  decoration: const InputDecoration(
                      border: InputBorder.none, hintText: "اعدد العنابر"),
                  keyboardType: TextInputType.number,
                ),
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  validator: (value) {
                    try {
                      return int.parse(value ?? "0") <= 0
                          ? "  0العدد يجب ان يكون اكبر من او يساوي"
                          : null;
                    } catch (e) {
                      return null;
                    }
                  },
                  decoration: const InputDecoration(
                      border: InputBorder.none, hintText: 'عدد عنابر العزل'),
                  keyboardType: TextInputType.number,
                ),
              ),
              Container(
                height: 50,
                decoration: BoxDecoration(
                    border: Border.all(
                  color: Colors.grey,
                )),
                padding: const EdgeInsets.all(10),
                child: TextFormField(
                  validator: (value) {},
                  decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: "ادخل عدد الافدنة الملحقة"),
                  keyboardType: TextInputType.number,
                ),
              ),
              Container(
                height: 90,
                padding: const EdgeInsets.all(0),
                child: CustomeDropdownButton(
                  list: const [
                    {"id": 0, "name": "عام"},
                    {"id": 1, "name": "خاص"}
                  ],
                  expanded: true,
                  text: "نوع القطاع",
                  value: 0,
                ),
              ),
              Container(height:180,child: GoogleMapComponent()),
              SizedBox(
                height: 230,
                child: Row(
                  children: [
                    Expanded(
                        child: BlocProvider(
                      create: (context) =>
                          ChoiceCubit(city: 0, gavernorate: 0, village: 0),
                      child: SelectLocation(),
                    )),
                  ],
                ),
              ),
              BlocProvider(
                create: (context) => SelectMuiltTypeCubit(list: []),
                child: Container(
                  child: CustomeType(
                    title: "نوع المزرعة",
                    list: const [
                      {"عام": 1},
                      {"خاص": 0}
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              OutlinedButton(
                style: ButtonStyle(
                    fixedSize: MaterialStateProperty.all(const Size(200, 50)),
                    shape: MaterialStateProperty.resolveWith((states) =>
                        RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30))),
                    backgroundColor: MaterialStateProperty.resolveWith(
                        (states) => Colors.grey),
                    overlayColor: MaterialStateProperty.resolveWith(
                        (states) => Colors.brown)),
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => const ShowInfoScreen(),
                      ));
                },
                child: const Text(
                  "حفظ",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          )),
        ),
      ),
    );
  }
}

class SelectLocation extends StatefulWidget {
  SelectLocation({Key? key, this.village}) : super(key: key);
  String? village;
  @override
  State<SelectLocation> createState() => _SelectLocationState();
}

class _SelectLocationState extends State<SelectLocation> {
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
            decoration: BoxDecoration(
                border: Border.all(
              color: Colors.grey,
            )),
            child: CustomeDropdownButton(
                func: (int value) {
                  BlocProvider.of<ChoiceCubit>(context)
                      .updateGavernorate(value);
                },
                list: const [
                  {"id": 0, "name": "اسيوط"},
                  {"id": 1, "name": "القاهرة"},
                  {"id": 2, "name": "المنةفية"}
                ],
                expanded: true,
                value: 0,
                text: "المحافظة")),
        Container(
          decoration: BoxDecoration(
              border: Border.all(
            color: Colors.grey,
          )),
          child: BlocBuilder<ChoiceCubit, ChoiceState>(
            buildWhen: (previous, current) {
              //
              return previous.gavernorate != current.gavernorate;
            },
            builder: (context, state) {
              return CustomeDropdownButton(
                  func: (int value) {
                    BlocProvider.of<ChoiceCubit>(context).updateCity(value);
                  },
                  list: const [
                    {"id": 1, "name": "القاهرة"},
                    {"id": 0, "name": "القاهرة"}
                  ],
                  expanded: true,
                  value: 0,
                  text: "المركز او المدينة");
            },
          ),
        ),
        
        Container(
          decoration: BoxDecoration(
              border: Border.all(
            color: Colors.grey,
          )),
          child: BlocBuilder<ChoiceCubit, ChoiceState>(
            buildWhen: (previous, current) {
              return previous.city != current.city ||
                  previous.gavernorate != current.gavernorate;
            },
            builder: (context, state) {
              return CustomeDropdownButton(
                  func: (int value) {
                    BlocProvider.of<ChoiceCubit>(context).updateVillage(value);
                  },
                  list: const [
                    {"id": 1, "name": "القاهرة"},
                    {"id": 0, "name": "القاهرة"}
                  ],
                  expanded: true,
                  value: 0,
                  text: "القرية او الشارع");
            },
          ),
        ),
      ],
    );
  }
}

class CustomeType extends StatefulWidget {
  List<Map<String, dynamic>> list;
  String title;
  bool visiable = false;
  _CustomeTypeState state = _CustomeTypeState();
  CustomeType({Key? key, required this.list, required this.title})
      : super(key: key);
  @override
  State<CustomeType> createState() {
    return _CustomeTypeState();
  }
}

class _CustomeTypeState extends State<CustomeType> {
  _CustomeTypeState();
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
            decoration: BoxDecoration(
                border: Border.all(
              color: Colors.grey,
            )),
            child: Directionality(
              textDirection: TextDirection.ltr,
              child: TextButton.icon(
                  onPressed: () {
                    widget.visiable = !widget.visiable;
                    setState(() {});
                  },
                  icon: Container(
                      padding: const EdgeInsets.only(right: 20),
                      child: const Icon(
                        Icons.arrow_drop_down,
                        color: Colors.black,
                        textDirection: TextDirection.rtl,
                        size: 24,
                      )),
                  label: Align(
                      alignment: AlignmentDirectional.centerEnd,
                      child: Text(widget.title,
                          style: const TextStyle(color: Colors.black)))),
            )),
        Visibility(
          visible: widget.visiable,
          child: Container(
            decoration: const BoxDecoration(
                border: Border(
              bottom: BorderSide(color: Colors.grey),
              right: BorderSide(color: Colors.grey),
              left: BorderSide(color: Colors.grey),
            )),
            height: 50,
            child: BlocBuilder<SelectMuiltTypeCubit, SelectMuiltTypeState>(
              builder: (context, state) {
                return ListView.builder(
                  itemCount: widget.list.length,
                  itemBuilder: (context, index) {
                    List<int> list = state.list;
                    CustomeButton d;
                    if (list.contains(index)) {
                      d = CustomeButton(
                        customeColor: Colors.brown,
                        f: (bool click) {
                          if (click) {
                            BlocProvider.of<SelectMuiltTypeCubit>(context)
                                .addToList(index);
                          } else {
                            BlocProvider.of<SelectMuiltTypeCubit>(context)
                                .removeToList(index);
                          }
                        },
                        click: true,
                        text: widget.list[index].keys.toList()[0],
                      );
                    } else {
                      d = CustomeButton(
                        customeColor: Colors.brown,
                        f: (bool click) {
                          if (click) {
                            BlocProvider.of<SelectMuiltTypeCubit>(context)
                                .addToList(index);
                          } else {
                            BlocProvider.of<SelectMuiltTypeCubit>(context)
                                .removeToList(index);
                          }
                        },
                        click: false,
                        text: widget.list[index].keys.toList()[0],
                      );
                    }
                    return d;
                  },
                );
              },
            ),
          ),
        ),
      ],
    );
  }
}

class CustomeButton extends StatefulWidget {
  String text;
  bool click;
  Function f;
  Color customeColor;
  CustomeButton({
    Key? key,
    required this.text,
    required this.customeColor,
    required this.click,
    required this.f,
  }) : super(key: key);

  @override
  State<CustomeButton> createState() => _CustomeButtonState();
}

class _CustomeButtonState extends State<CustomeButton> {
  @override
  Widget build(BuildContext context) {
    return TextButton(
      style: ButtonStyle(
          shape: MaterialStateProperty.resolveWith((states) =>
              RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(0),
                  side: const BorderSide(color: Colors.grey))),
          backgroundColor: MaterialStateProperty.resolveWith(
              (states) => widget.click ? widget.customeColor : null)),
      onPressed: () {
        widget.click = !widget.click;
        widget.f(widget.click);
        setState(() {});
      },
      child: Text(widget.text, style: const TextStyle(color: Colors.black)),
    );
  }
}

class GoogleMapComponent extends StatefulWidget {
  const GoogleMapComponent({super.key});

  @override
  State<GoogleMapComponent> createState() => _GoogleMapComponentState();
}

class _GoogleMapComponentState extends State<GoogleMapComponent> {
   static const   CameraPosition _kLake = CameraPosition(
      bearing: 192.8334901395799,
      target: LatLng(37.43296265331129, -122.08832357078792),
      tilt: 59.440717697143555,
      zoom: 19.151926040649414);
  Completer<GoogleMapController> _controller = Completer();
  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(height: 100,
          child: GoogleMap(mapType: MapType.hybrid,
            initialCameraPosition: _GoogleMapComponentState._kLake,
            onMapCreated: (GoogleMapController controller) {
            //_controller.complete(controller);
          },
            ),
           
        ),
Row(
  children: [
        Expanded(
          child: Container(
                        height: 50,
                        decoration: BoxDecoration(
                            border: Border.all(
                          color: Colors.grey,
                        )),
                        padding: const EdgeInsets.all(10),
                        child: TextFormField(
                          validator: (value) {},
                          decoration: const InputDecoration(
                              border: InputBorder.none,
                              hintText: 'المساحة الكلية للمزرعة'),
                          keyboardType: TextInputType.number,
                        ),
                      ),
        ),
        Directionality(textDirection: TextDirection.rtl,
          child: Container(width:80 ,
            child: TextButton(onPressed: () {
              
            }, style: TextButton.styleFrom(backgroundColor:Colors.brown),child: Text('تغير ال google map',style: TextStyle(color: Colors.white),)),
          ),
        )
  ],
),
         
      ],
    );
  }
}
