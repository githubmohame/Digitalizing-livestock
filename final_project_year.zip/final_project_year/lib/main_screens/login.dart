import 'package:final_project_year/common_component/main_diwer.dart';
import 'package:flutter/material.dart';

class LogIN extends StatelessWidget {
  LogIN({Key? key}) : super(key: key);
  final _formKey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.rtl,
      child: Scaffold( appBar: AppBar(backgroundColor: Colors.brown ,elevation: 0,title: const Text('تسجيل الدخول'),),backgroundColor: Colors.white,drawer: MainDrawer(index: 4),   body: Column(crossAxisAlignment: CrossAxisAlignment.center,mainAxisAlignment: MainAxisAlignment.center,children: [
        Form(child: Column(children: [
          const Icon(Icons.person,color:Colors.white,size:50),
              const TextField(keyboardType: TextInputType.number,style:TextStyle(color:Colors.brown),decoration: InputDecoration(hintText: "ادخل الرقم القومي",prefixIcon: Icon(Icons.email,color: Colors.brown,),border :OutlineInputBorder(borderSide: BorderSide(color:Colors.grey,width: 5)),focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey,width: 2)) ,focusColor: Colors.grey,enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey,width: 2)))),
              const SizedBox(height: 20),
              const TextField(style:TextStyle(color:Colors.brown),decoration: InputDecoration(hintText: "اكتب الرقم السري",prefixIcon: Icon(Icons.password,color: Colors.brown,),border :OutlineInputBorder(borderSide: BorderSide(color:Colors.grey,width: 5)),focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey,width: 2)) ,focusColor: Colors.green,enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey,width: 2)))),
              const SizedBox(height:20,),
              Container(height: 50,width: 200,
                child: TextButton(onPressed: () {
                  
                }, style: ButtonStyle(shape: MaterialStateProperty.all<RoundedRectangleBorder>(
      RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18.0),
            side: const BorderSide(color: Colors.transparent)
      )
      ),backgroundColor: MaterialStateProperty.resolveWith((states) => Colors.grey),side:MaterialStateProperty.resolveWith((states) => const BorderSide(color: Colors.grey,style: BorderStyle.solid)) ),child: const Text('تسجيل الدخول',style:TextStyle(color: Colors.white))),
              ),
        ],))
          ],),),
    );
  }
}