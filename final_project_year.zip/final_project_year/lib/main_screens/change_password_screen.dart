import 'package:final_project_year/common_component/main_diwer.dart';
import 'package:flutter/material.dart' hide Stepper, Step, StepperType;
import 'package:final_project_year/common_component/custome_stepper.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  int x = 0;
  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: TextDirection.rtl,
      child: Scaffold(drawer: MainDrawer(index: 10,),
        appBar: AppBar(
          backgroundColor: Colors.brown.shade100,
          title: const Center(
              child: Center(
                  child: Text(
            'تغير الرقم السري',
            style: TextStyle(color: Colors.brown),
          ))),
        ),
        body: Directionality(
          textDirection: TextDirection.rtl,
          child: SafeArea(
              child: Container(
            color: Colors.brown,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 260,
                  color: Colors.brown,
                  child: Theme(
                    data: ThemeData(
                      primaryColor: Colors.green,
                      colorScheme: const ColorScheme.light(),
                      canvasColor: Colors.brown,
                    ),
                    child: LayoutBuilder(builder: (context, constraint) {
                      return SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Container(
                          height: 200,
                          width: 500 < constraint.maxWidth
                              ? constraint.maxWidth
                              : 500,
                          child: CustomeStepper(
                              margin: const EdgeInsets.all(5),
                              elevation: 0,
                              onStepContinue: x < 2
                                  ? () {
                                      setState(() {
                                        x += 1;
                                      });
                                    }
                                  : x == 2
                                      ? () {}
                                      : null,
                              onStepCancel: x > 0
                                  ? () {
                                      x -= 1;
                                      setState(() {});
                                    }
                                  : null,
                              currentStep: x,
                              onStepTapped: (value) {
                                setState(() {
                                  x = value;
                                });
                              },
                              type: StepperType.horizontal,
                              controlsBuilder: (context, details) {
                                return Container(
                                    child: Row(
                                  children: [
                                    TextButton(
                                      onPressed: details.onStepContinue,
                                      child: Text(
                                        x == 2 ? 'حفظ' : 'استكمال',
                                        style: TextStyle(color: Colors.white),
                                      ),
                                      style: ButtonStyle(backgroundColor:
                                          MaterialStateProperty.resolveWith(
                                              (states) {
                                        if (details.onStepContinue == null) {
                                          return Colors.brown;
                                        } else if (x == 2)
                                          return Colors.green;
                                        else {
                                          return Colors.brown.shade300;
                                        }
                                      })),
                                    ),
                                    x == 0
                                        ? Container()
                                        : TextButton(
                                            onPressed: details.onStepCancel,
                                            child: const Text(
                                              'تراجع',
                                              style:
                                                  TextStyle(color: Colors.white),
                                            ),
                                            style: ButtonStyle(
                                              backgroundColor:
                                                  MaterialStateProperty
                                                      .resolveWith((states) =>
                                                          details.onStepCancel ==
                                                                  null
                                                              ? Colors.brown
                                                              : Colors.brown
                                                                  .shade300),
                                            ))
                                  ],
                                ));
                              },
                              steps: [
                                Step(
                                    isActive: x == 0,
                                    title: const Text("ادخل البريد الاليكتروني"),
                                    content: Container(
                                      height: 60,
                                      color: Colors.white,
                                      child: Column(
                                        children: const [
                                          TextField(
                                            keyboardType:
                                                TextInputType.emailAddress,
                                            decoration: InputDecoration(
                                                focusColor: Colors.white,
                                                enabledBorder: OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                  color: Colors.white,
                                                )),
                                                focusedBorder: OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                  color: Colors.white,
                                                )),
                                                border: OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                  color: Colors.white,
                                                )),
                                                hintText: "البريد الاليكتروني"),
                                          ),
                                        ],
                                      ),
                                    )),
                                Step(
                                    isActive: x == 1,
                                    title: const Text(
                                      'التأكيد',
                                    ),
                                    content: Container(
                                      color: Colors.brown,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                              "لقد قمنا بارسال كود لك على البريد الالكتروني من فضلك ادخل الكود",
                                              style: TextStyle(
                                                  color: Colors.brown.shade100)),
                                          const SizedBox(
                                            height: 10,
                                          ),
                                          const TextField(
                                            decoration: InputDecoration(
                                                fillColor: Colors.white,
                                                focusColor: Colors.white,
                                                enabledBorder: OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                  color: Colors.white,
                                                )),
                                                focusedBorder: OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                  color: Colors.white,
                                                )),
                                                filled: true,
                                                border: OutlineInputBorder(
                                                    borderSide: BorderSide(
                                                  color: Colors.white,
                                                )),
                                                hintText: " ادخل الكود"),
                                          )
                                        ],
                                      ),
                                    )),
                                Step(
                                    isActive: x == 2,
                                    title: const Text(
                                      'ادخل الرقم السري',
                                    ),
                                    content: CustomePasswordTextField())
                              ]),
                        ),
                      );
                    }),
                  ),
                ),
              ],
            ),
          )),
        ),
      ),
    );
  }
}

class CustomePasswordTextField extends StatefulWidget {
  const CustomePasswordTextField({super.key});

  @override
  State<CustomePasswordTextField> createState() =>
      _CustomePasswordTextFieldState();
}

class _CustomePasswordTextFieldState extends State<CustomePasswordTextField> {
  bool showPassword = false;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      color: Colors.brown,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(obscureText: !showPassword,obscuringCharacter: '*',
            decoration: InputDecoration(
              
                fillColor: Colors.white,
                focusColor: Colors.white,
                enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                  color: Colors.white,
                )),
                focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                  color: Colors.white,
                )),
                filled: true,
                border: OutlineInputBorder(
                    borderSide: BorderSide(
                  color: Colors.white,
                )),
                hintText: " ادخل الرقم السري"),
          ),
          SizedBox(height: 10),
          TextField(obscureText: !showPassword,obscuringCharacter: '*',
            decoration: InputDecoration(
                fillColor: Colors.white,
                focusColor: Colors.white,
                enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                  color: Colors.white,
                )),
                focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(
                  color: Colors.white,
                )),
                filled: true,
                border: OutlineInputBorder(
                    borderSide: BorderSide(
                  color: Colors.white,
                )),
                hintText: " ادخل تاكيد الرقم السري"),
          ),
          Row(
            children: [
              Checkbox(side: BorderSide(color: Colors.white),
                  value: showPassword,
                  onChanged: (value) {
                    setState(() {
                      showPassword = value??false;
                    });
                  }),
                  Text('اظهار كلمة المرور',style:TextStyle(color: Colors.white,fontWeight: FontWeight.w100))
            ],
          )
        ],
      ),
    );
  }
}
/*
  Step(
                               
                                  content: )

*/